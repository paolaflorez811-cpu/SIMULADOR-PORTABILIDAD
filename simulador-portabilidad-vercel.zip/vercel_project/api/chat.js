// api/chat.js
// Función serverless que actúa como intermediario seguro entre el navegador
// y la API de Anthropic. La API key nunca se expone al cliente: vive como
// variable de entorno en Vercel (ANTHROPIC_API_KEY).

export default async function handler(req, res) {
  // Solo permitir POST
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ error: 'Método no permitido. Usa POST.' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: 'ANTHROPIC_API_KEY no está configurada en las variables de entorno de Vercel.'
    });
  }

  try {
    const { system, messages, max_tokens } = req.body || {};

    if (!messages) {
      return res.status(400).json({ error: 'Falta el campo "messages" en el body.' });
    }

    const anthropicResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: max_tokens || 1000,
        system: system || undefined,
        messages: messages,
      }),
    });

    const data = await anthropicResponse.json();

    if (!anthropicResponse.ok) {
      return res.status(anthropicResponse.status).json({
        error: data.error?.message || 'Error al llamar a la API de Anthropic.',
        detail: data,
      });
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('Error en /api/chat:', err);
    return res.status(500).json({ error: 'Error interno del servidor: ' + err.message });
  }
}
