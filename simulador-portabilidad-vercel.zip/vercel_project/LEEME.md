# Simulador de cliente — Despliegue en Vercel

Este paquete convierte tu simulador en una app real con link público,
usando tu propia API key de Anthropic guardada de forma segura (nunca
visible en el navegador).

## Contenido del paquete

- `index.html` — el simulador (ya ajustado para usar tu backend)
- `api/chat.js` — la función serverless que habla con Anthropic usando tu key
- `vercel.json` — configuración de Vercel
- `package.json` — metadatos del proyecto

## Paso 1 — Consigue tu API key de Anthropic

1. Ve a https://console.anthropic.com
2. Crea una cuenta (o inicia sesión) y agrega método de pago (la API se cobra
   por uso, aparte de tu suscripción de Claude.ai — son cosas distintas).
3. Ve a "API Keys" y crea una nueva key. Cópiala (empieza con `sk-ant-...`).
   Guárdala en un lugar seguro, no la compartas ni la subas a internet.

## Paso 2 — Sube este proyecto a Vercel

### Opción fácil (sin usar la terminal)

1. Crea una cuenta gratis en https://vercel.com (puedes entrar con GitHub,
   GitLab o email).
2. Sube este proyecto a un repositorio de GitHub:
   - Crea un repositorio nuevo en https://github.com/new
   - Sube estos archivos (arrastrándolos en la interfaz web de GitHub, opción
     "uploading an existing file", o con GitHub Desktop si prefieres algo
     visual).
3. En Vercel, haz clic en "Add New... > Project", elige "Import Git
   Repository" y selecciona el repositorio que acabas de crear.
4. Antes de darle "Deploy", baja hasta "Environment Variables" y agrega:
   - **Name**: `ANTHROPIC_API_KEY`
   - **Value**: la key que copiaste en el Paso 1 (empieza con `sk-ant-...`)
5. Haz clic en "Deploy". En un par de minutos te dará un link como
   `https://tu-proyecto.vercel.app` — ese es tu link público y funcional.

### Opción con terminal (más rápida si ya usas la línea de comandos)

```bash
npm install -g vercel
cd simulador-portabilidad
vercel login
vercel

# Cuando pregunte, dale nombre al proyecto y acepta los defaults.
# Luego agrega la variable de entorno:
vercel env add ANTHROPIC_API_KEY
# Pega tu key cuando te la pida, elige "Production" (y opcionalmente
# "Preview" y "Development" también).

# Despliega a producción:
vercel --prod
```

## Paso 3 — Prueba

Abre el link que te dio Vercel, dale "Nuevo cliente" y escribe una respuesta.
Ya no debería aparecer "Failed to fetch" — el navegador ahora llama a tu
propia función `/api/chat`, que internamente usa tu key para hablar con
Anthropic.

## Notas importantes

- **Costo**: cada mensaje que envíes en el simulador consume tokens de la
  API de Anthropic (se cobra por uso, precios en
  https://www.anthropic.com/pricing). Para uso de entrenamiento con varios
  asesores, revisa el volumen esperado y pon límites de gasto en la consola
  de Anthropic si te preocupa el costo.
- **Seguridad**: tu API key vive solo en Vercel (variable de entorno), nunca
  en el HTML/JS que ve el navegador. No la pegues directamente en
  `index.html` bajo ninguna circunstancia.
- **Actualizaciones**: si luego quieres cambiar el diseño o los clientes
  simulados, edita `index.html` y vuelve a desplegar (`vercel --prod` o
  sube los cambios al repositorio si usaste la opción de GitHub).
